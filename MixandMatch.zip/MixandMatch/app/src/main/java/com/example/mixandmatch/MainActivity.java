package com.example.mixandmatch;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Game();










    }
    public void Exit(View view){
        finish();
    }

    public void Game(){
        ImageButton card1 = findViewById(R.id.card1);// Idk how to automate this.
        ImageButton card2 = findViewById(R.id.card2);
        ImageButton card3 = findViewById(R.id.card3);
        ImageButton card4 = findViewById(R.id.card4);
        ImageButton card5 = findViewById(R.id.card5);
        ImageButton card6 = findViewById(R.id.card6);
        ImageButton card7 = findViewById(R.id.card7);
        ImageButton card8 = findViewById(R.id.card8);
        ImageButton card9 = findViewById(R.id.card9);
        ImageButton card10 = findViewById(R.id.card10);
        ImageButton card11 = findViewById(R.id.card11);
        ImageButton card12 = findViewById(R.id.card12);


        List<Integer> taglist = new ArrayList<>(Arrays.asList(1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6));
        Collections.shuffle(taglist);//Responsible for Shuffling and pairing tags.
        card1.setTag(taglist.get(0));
        card2.setTag(taglist.get(1));
        card3.setTag(taglist.get(2));
        card4.setTag(taglist.get(3));
        card5.setTag(taglist.get(4));
        card6.setTag(taglist.get(5));
        card7.setTag(taglist.get(6));
        card8.setTag(taglist.get(7));
        card9.setTag(taglist.get(8));
        card10.setTag(taglist.get(9));
        card11.setTag(taglist.get(10));
        card12.setTag(taglist.get(11));
        TextView scoretext = findViewById(R.id.score);
        RelativeLayout Fullscreen = findViewById(R.id.Fullscreen);




        final int[] score = {0};
        final int TotalPairs = 6;
        final int[] TotalPairsMatched = {0};
        final int[] selectedTag = {0};
        final ImageButton[] selectedCard = {null};



        View.OnClickListener cardClickListener = new View.OnClickListener() {// Adds a listener to the Cards
            public void onClick(View v) {
                ImageButton CurrentImage = (ImageButton) v;
                final int currentTag = (int) CurrentImage.getTag();
                if(currentTag == 1){
                    CurrentImage.setImageResource(R.drawable.car);
                }
                else if (currentTag == 2){
                    CurrentImage.setImageResource(R.drawable.bike);
                }
                else if (currentTag == 3){
                    CurrentImage.setImageResource(R.drawable.camera);
                }
                else if (currentTag == 4){
                    CurrentImage.setImageResource(R.drawable.sun);
                }
                else if (currentTag == 5){
                    CurrentImage.setImageResource(R.drawable.trash);
                }
                else if (currentTag == 6){
                    CurrentImage.setImageResource(R.drawable.corona);
                }
                CurrentImage.setClickable(false);//Sets the Current Image to be unclickable to prevent Spammable Cards lmao.
                if (selectedCard[0] == null){// If its null, then it grabs both the Current Image and Tag.
                    selectedCard[0] = CurrentImage;
                    selectedTag[0] = currentTag;
                    Log.d("Catch", "Grabbed.");
                }//It will never go to to the Else because once it Matches, selectedCard[0] becomes Null again.
                else{// If its NOT NULL, then it checks if it matches.
                    if(selectedTag[0] == currentTag){
                        TotalPairsMatched[0]++;
                        score[0] += 10;
                        scoretext.setText(String.valueOf(score[0]));
                        Log.d("Matched", "It Worked.");

                        if (TotalPairsMatched[0] == TotalPairs){

                            // Resets the Cards
                            List<ImageButton> cards = Arrays.asList(card1, card2, card3, card4, card5, card6, card7, card8, card9, card10, card11, card12);
                            List<Integer> tags = new ArrayList<>(Arrays.asList(1,1,2,2,3,3,4,4,5,5,6,6));
                            Collections.shuffle(tags);
                            for (int i = 0; i < cards.size(); i++) {
                                ImageButton cardView = cards.get(i);//Gets from the Array [0] is card1, etc.
                                cardView.setTag(tags.get(i));//Sets NEW tags using the int i as the basis, and tags ArrayList is already shuffled.
                                cardView.setImageResource(R.color.black);
                                cardView.setClickable(true);
                            }
                            TotalPairsMatched[0] = 0;// Resets Game once TotalPairsMatched is equal to TotalPairs.


                        }

                    }
                    else{


                            selectedCard[0].setImageResource(R.color.black);
                            selectedCard[0].setClickable(true);
                            CurrentImage.setImageResource(R.color.black);
                            CurrentImage.setClickable(true);





                    }
                    selectedCard[0] = null;
                    selectedTag[0] = -1;
                }
            }
        };
        for (ImageButton card : Arrays.asList(card1, card2, card3, card4, card5, card6, card7, card8, card9, card10, card11, card12)) {
            card.setOnClickListener(cardClickListener);// Adds OnClickListeners to the Buttons here because I don't wanna add it it in the XML.
        }
    }

}
